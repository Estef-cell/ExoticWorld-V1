package com.example.exoticworld.data.model

data class Animalitos(val id : Int,
                      val nombre : String,
                      val descripción : String)