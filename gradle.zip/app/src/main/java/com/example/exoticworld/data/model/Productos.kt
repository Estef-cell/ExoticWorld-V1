package com.example.exoticworld.data.model

data class Productos(
    val id: Int,
    val nombre: String,
    val descripcion: String,
    val precio: Int,
    val categoriaId: Int
)
